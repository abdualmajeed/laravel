@extends('dashboard.layouts.app')
@section('content')
<div class="profile-container d-flex flex-wrap g-5  align-items-center">
  
    <div class=" col-lg-5 col-md-5 col-11 m-lg-0 m-auto text-white text-end">
        <h4 class="text-warning text-center fs-4  m-2">
            المعلومات الشخصية
        </h4>
        <h5 class=" mt-5">معلومات التواصل </h5>

        <div>
            <table class="table-profile">

                <tr>
                    <th>
                        البريد الالكتروني
                    </th>
                    <td>
                        Email
                    </td>
                </tr>
                <th>
                    كلمة السر
                </th>
                <td>
                    *********
                </td>

                </tr>
                    <th>
                        رقم التلفون
                    </th>
                    <td>
                    Phone                    
                </td>
                    </tr>

            </table>
        </div>
    </div>
</div>
@endsection

@extends('dashboard.layouts.app')
@section('content')
<section>
@if (count($taskUsers) === 0)
    <div class="container">
        <div class="alert alert-danger p-20">
            No Task Found
            <br>
            <br>
            {{-- <a href="{{ route('task.create') }}" class="btn btn-info">
                <i class="fa fa-plus-circle"></i> Create Task
            </a> --}}
        </div>
    </div>
@else
    <div class="container">
        
        <div class="row">
            <table class="table">
                <thead>
                

                <tr>
                    {{-- <th>id</th> --}}
                    <th>User Name</th>
                    <th>Task Name</th>
                    <th>Has Complated</th>
                    <th>Task Date</th>
                    <th>Status</th>
                    
                </tr>

            </thead>
            <tbody>

                @foreach ($taskUsers as $task)
                    <tr>
                        {{-- <td>{{$task->id}}</td> --}}
                        <td>{{$task->user->name}}</td>
                        <td>{{$task->task->name}}</td>
                        @if($task->complated == 0)
                        <td class="text-danger">
                            <button type="button" class="btn btn-danger" style="color: white">
                                in progress
                            </button>
                        </td>
                        @else
                        <td class="text-info">
                            <button type="button" class="btn btn-success">
                            complated
                            </button>
                        
                        </td>
                        @endif
                        <td >{{$task->created_at->format('y/d/m')}}</td>
                        @if($task->status == 0)
                        <td class="text-danger"><a href="{{route('status_task' , $task->id)}}" >non active</a></td>
                        @else
                        <td class="text-danger"><a href="{{route('status_task' , $task->id)}}"> active</a></td>
                        @endif
                    </tr>
                @endforeach
            </tbody>
                
            </table>
        </div>
    </div>
    
@endif
</section>


@endsection


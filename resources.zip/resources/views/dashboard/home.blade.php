@extends('dashboard.layouts.app')
@section('content')
<br/>
<br/>
<div class="container" align="center">
<h1>Wellcom To Task Manager</h1>
<div class="container">
    <img src="/assets/image/hello.jpg" class="d-block w-50" alt="..." />
</div>
</div>
@endsection
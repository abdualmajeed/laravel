@extends('dashboard.layouts.app')
@section('content')
<section>
    <div class="container">
        @if (session()->has('message'))
        
            <p class="alert alert-info">{{ session()->get('message') }}</p>
        
        @endif
        <div>
            <div class="float-start">
                <h4 class="pb-3">All Employee</h4>
            </div>
            <div class="float-end">
                <a href="{{route('addUser')}}" class="btn btn-info">
                    <i class="fa fa-plus-circle"></i> Add Employee
                </a>
            </div>
            <div class="clearfix"></div>
        
        </div>


    <div class="container">
        {{-- <a href="" class="btn btn-primary">Add</a> --}}
        <div class="row">
            <table class="table">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>name</th>
                        <th>email</th>
                        <th>phone</th>
                        <th>Type</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user)
                        <tr>
                            <td>{{$user->id}}</td>
                            <td>{{$user->name}}</td>
                            <td>{{$user->email}}</td>
                            <td>{{$user->phone}}</td>
                            @if($user->hasRole('client'))
                            <td>Employee</td>
                            @else
                            <td>Admin</td>
                            @endif
                            @if($user->name == 'shehab')
                            <td>Admin</td> 
                            @else
                            <td>
                            <div style="display: inline">
                                <form action="{{ route('user.destroy' , $user->id) }} " style="display: inline" method="POST" onsubmit="return confirm('Are you sure to delete ?')">
                                {{-- {{ route('task.destroy', $task->id) }} --}}
                                @csrf
                                @method('DELETE')
                                    <button type="submit" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>Delete
                                    </button>
        
                                </form>
                            </div>
                            <td>
                            @endif
                        </tr>
                    
                    @endforeach
                <tbody>   
            </table>
        </div>
    </div>
</section>
@endsection